export const environment = {
  production: false,
  backendHost: "http://localhost:8021"
};
