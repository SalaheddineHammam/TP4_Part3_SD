package ma.fsm.tp4part3.entities;

public enum PaymentStatus {
    CREATED, VALIDATED, REJECTED
}
