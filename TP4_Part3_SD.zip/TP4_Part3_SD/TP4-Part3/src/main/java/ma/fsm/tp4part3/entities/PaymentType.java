package ma.fsm.tp4part3.entities;

public enum PaymentType {
    CASH, CHECK, TRANSFER, DEPOSIT
}
