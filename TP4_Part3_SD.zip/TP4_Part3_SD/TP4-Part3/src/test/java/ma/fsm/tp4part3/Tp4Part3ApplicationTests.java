package ma.fsm.tp4part3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp4Part3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
